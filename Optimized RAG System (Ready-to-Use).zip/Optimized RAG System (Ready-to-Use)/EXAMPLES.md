# RAG System v8 - Usage Examples

## Example 1: Basic Indexing and Query

```python
#!/usr/bin/env python3
"""Simple example: Index documents and ask questions."""

import sys
from RAG_optimized_v8 import (
    index_folder, load_index, EmbeddingManager, 
    HybridRetriever, query_index, DEVICE
)

# Step 1: Index documents (one-time)
print("📚 Indexing documents...")
try:
    index_folder(folder_path="./documents")
except FileExistsError:
    print("Index already exists, skipping...")

# Step 2: Initialize retriever
print("\n🔧 Initializing retriever...")
index, metadata = load_index()
embedding_manager = EmbeddingManager()
retriever = HybridRetriever(index, metadata, device=DEVICE)

# Step 3: Ask questions
questions = [
    "What is the main topic of the documents?",
    "Summarize the key findings.",
    "List any errors or issues mentioned."
]

for q in questions:
    print(f"\n❓ Q: {q}")
    answer = query_index(
        q,
        k=5,
        retriever=retriever,
        embedding_manager=embedding_manager
    )
    print(f"✅ A: {answer}\n")
```

**Usage:**
```bash
python example1_basic.py
```

---

## Example 2: Interactive Chat Session

```python
#!/usr/bin/env python3
"""Interactive multi-turn conversation with memory."""

from RAG_optimized_v8 import (
    load_index, EmbeddingManager, HybridRetriever, 
    query_index, ConversationalMemory, DEVICE
)

def main():
    print("🚀 RAG System v8 - Interactive Chat")
    print("Type 'exit' to quit, 'stats' to show performance\n")
    
    # Initialize
    index, metadata = load_index()
    embedding_manager = EmbeddingManager()
    retriever = HybridRetriever(index, metadata, device=DEVICE)
    memory = ConversationalMemory(max_turns=5)
    
    # Chat loop
    while True:
        question = input("\n💬 You: ").strip()
        
        if question.lower() == 'exit':
            print("Goodbye! 👋")
            break
        
        if question.lower() == 'stats':
            from RAG_optimized_v8 import perf_monitor
            perf_monitor.print_query_stats()
            continue
        
        if not question:
            continue
        
        # Query with conversation history
        answer = query_index(
            question,
            k=5,
            retriever=retriever,
            embedding_manager=embedding_manager,
            conversational_memory=memory
        )
        
        print(f"\n🤖 Assistant: {answer}")
        
        # Store in memory for next turn
        memory.add_turn(question, answer)

if __name__ == "__main__":
    main()
```

**Usage:**
```bash
python example2_interactive.py
```

**Example session:**
```
💬 You: What is the main topic?
🤖 Assistant: The main topic is... [answer]

💬 You: Can you summarize that?
🤖 Assistant: Summary: ... [uses conversation history]

💬 You: exit
Goodbye! 👋
```

---

## Example 3: Batch Processing Multiple Files

```python
#!/usr/bin/env python3
"""Process multiple CSV queries and save results."""

import csv
from RAG_optimized_v8 import (
    load_index, EmbeddingManager, HybridRetriever,
    query_index, DEVICE
)

def process_batch(input_csv, output_csv):
    """Read queries from CSV, write answers to CSV."""
    
    # Initialize
    index, metadata = load_index()
    embedding_manager = EmbeddingManager()
    retriever = HybridRetriever(index, metadata, device=DEVICE)
    
    # Read input
    queries = []
    with open(input_csv, 'r') as f:
        reader = csv.DictReader(f)
        queries = list(reader)
    
    print(f"Processing {len(queries)} queries...")
    
    # Process each query
    results = []
    for i, row in enumerate(queries, 1):
        question = row.get('question', '')
        
        print(f"[{i}/{len(queries)}] {question[:50]}...")
        
        answer = query_index(
            question,
            k=5,
            retriever=retriever,
            embedding_manager=embedding_manager
        )
        
        results.append({
            'question': question,
            'answer': answer,
            'status': 'success'
        })
    
    # Write output
    with open(output_csv, 'w', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=['question', 'answer', 'status'])
        writer.writeheader()
        writer.writerows(results)
    
    print(f"✅ Results saved to {output_csv}")

if __name__ == "__main__":
    # Example: Read queries.csv, write answers.csv
    process_batch('queries.csv', 'answers.csv')
```

**Input CSV (queries.csv):**
```csv
question
What is the main topic?
Summarize key findings
List errors mentioned
```

**Usage:**
```bash
python example3_batch.py
# Output: answers.csv with questions and answers
```

---

## Example 4: Document Search with Filtering

```python
#!/usr/bin/env python3
"""Search documents with filtering by source."""

from RAG_optimized_v8 import (
    load_index, EmbeddingManager, HybridRetriever, DEVICE
)
import json

def search_with_filters(query, k=5, file_type=None, source_path=None):
    """Search documents with optional filtering."""
    
    # Initialize
    index, metadata = load_index()
    embedding_manager = EmbeddingManager()
    retriever = HybridRetriever(index, metadata, device=DEVICE)
    
    # Retrieve documents
    print(f"🔍 Searching for: {query}")
    results = retriever.query(query, embedding_fn=embedding_manager.embed_texts, top_k=k*2)
    
    # Apply filters
    filtered = []
    for doc_text in results:
        # Find metadata for this document
        for meta in metadata:
            if meta['text'][:100] in doc_text[:100]:
                # Check file type filter
                if file_type and meta.get('file_type') != file_type:
                    continue
                
                # Check source filter
                if source_path and source_path not in meta.get('path', ''):
                    continue
                
                filtered.append({
                    'text': doc_text[:500],
                    'source': meta.get('path', 'unknown'),
                    'file_type': meta.get('file_type', 'unknown')
                })
                break
    
    return filtered[:k]

def main():
    # Example 1: Search all documents
    print("Example 1: General search")
    results = search_with_filters("main topic", k=3)
    for r in results:
        print(f"  Source: {r['source']}")
        print(f"  Text: {r['text'][:100]}...\n")
    
    # Example 2: Search only PDF documents
    print("\nExample 2: PDF-only search")
    results = search_with_filters("important information", k=3, file_type='pdf')
    for r in results:
        print(f"  Source: {r['source']}")
        print(f"  Type: {r['file_type']}\n")
    
    # Example 3: Search specific folder
    print("\nExample 3: Search in specific source")
    results = search_with_filters("data", k=3, source_path="documents/reports")
    for r in results:
        print(f"  Source: {r['source']}\n")

if __name__ == "__main__":
    main()
```

**Usage:**
```bash
python example4_search_filter.py
```

---

## Example 5: Performance Comparison

```python
#!/usr/bin/env python3
"""Compare performance of different configurations."""

import time
from RAG_optimized_v8 import (
    load_index, EmbeddingManager, HybridRetriever,
    DEVICE, perf_monitor
)

def benchmark_query(question, retriever, embedding_manager, k=5, num_runs=5):
    """Benchmark query time."""
    times = []
    
    for _ in range(num_runs):
        start = time.time()
        results = retriever.query(
            question,
            embedding_fn=embedding_manager.embed_texts,
            top_k=k
        )
        times.append(time.time() - start)
    
    return {
        'avg': sum(times) / len(times),
        'min': min(times),
        'max': max(times),
        'total': sum(times)
    }

def main():
    print("Benchmarking RAG System v8\n")
    print(f"Device: {DEVICE.upper()}")
    
    # Initialize
    index, metadata = load_index()
    embedding_manager = EmbeddingManager()
    retriever = HybridRetriever(index, metadata, device=DEVICE)
    
    # Test different query complexities
    queries = [
        ("What is this?", 5),
        ("Provide detailed summary of findings", 8),
        ("List all errors with timestamps", 10),
    ]
    
    print("\nBenchmark Results (5 runs each):\n")
    print(f"{'Query':<35} {'Avg (ms)':<12} {'Min (ms)':<12} {'Max (ms)':<12}")
    print("-" * 70)
    
    for query_text, k in queries:
        result = benchmark_query(query_text, retriever, embedding_manager, k=k, num_runs=5)
        
        print(f"{query_text:<35} {result['avg']*1000:<12.2f} {result['min']*1000:<12.2f} {result['max']*1000:<12.2f}")
    
    # Print saved stats
    print("\n" + "="*70)
    perf_monitor.print_query_stats()

if __name__ == "__main__":
    main()
```

**Usage:**
```bash
python example5_benchmark.py
```

**Output:**
```
Benchmarking RAG System v8
Device: CUDA

Benchmark Results (5 runs each):

Query                           Avg (ms)     Min (ms)     Max (ms)
----------------------------------------------------------------------
What is this?                   2450.32      2320.15      2680.45
Provide detailed summary...     3120.67      2980.40      3350.20
List all errors with ...        4230.15      4010.80      4520.35
```

---

## Example 6: Custom Index Creation

```python
#!/usr/bin/env python3
"""Create index from custom data programmatically."""

import numpy as np
from RAG_optimized_v8 import (
    create_optimized_faiss_index, EmbeddingManager,
    BATCH_SIZE
)
import faiss
import json

def create_custom_index(documents, output_index="custom_index.bin", output_metadata="custom_metadata.json"):
    """Create FAISS index from custom documents."""
    
    print(f"Creating index for {len(documents)} documents...")
    
    # Initialize embedding manager
    embedding_manager = EmbeddingManager()
    
    # Extract text from documents
    texts = [doc['content'] for doc in documents]
    
    # Generate embeddings
    print("Generating embeddings...")
    embeddings = embedding_manager.embed_texts(texts, batch_size=BATCH_SIZE)
    
    # Create FAISS index
    print("Creating FAISS index...")
    index = create_optimized_faiss_index(embeddings)
    
    # Save index
    faiss.write_index(index, output_index)
    print(f"✓ Index saved to {output_index}")
    
    # Save metadata
    metadata = [
        {
            'text': doc['content'][:1000],
            'source': doc.get('source', 'custom'),
            'id': i
        }
        for i, doc in enumerate(documents)
    ]
    
    with open(output_metadata, 'w') as f:
        json.dump(metadata, f, indent=2)
    print(f"✓ Metadata saved to {output_metadata}")
    
    return index, metadata

def main():
    # Example: Create index from programmatic data
    documents = [
        {
            'content': 'Machine learning is a subset of artificial intelligence...',
            'source': 'textbook'
        },
        {
            'content': 'Deep learning uses neural networks with multiple layers...',
            'source': 'research_paper'
        },
        {
            'content': 'Natural language processing enables computers to understand text...',
            'source': 'article'
        }
    ]
    
    index, metadata = create_custom_index(documents)
    print("\n✅ Custom index created successfully!")

if __name__ == "__main__":
    main()
```

**Usage:**
```bash
python example6_custom_index.py
```

---

## Example 7: Integration with FastAPI

```python
#!/usr/bin/env python3
"""REST API for RAG system using FastAPI."""

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import time
from RAG_optimized_v8 import (
    load_index, EmbeddingManager, HybridRetriever,
    query_index, perf_monitor, DEVICE
)

app = FastAPI(title="RAG System v8 API")

# Global models (loaded once)
index = None
embedding_manager = None
retriever = None

class QueryRequest(BaseModel):
    question: str
    k: int = 5
    log_level: str = None

class QueryResponse(BaseModel):
    question: str
    answer: str
    processing_time: float
    success: bool

@app.on_event("startup")
async def startup():
    """Initialize models on startup."""
    global index, embedding_manager, retriever
    
    print("Loading models...")
    index, metadata = load_index()
    embedding_manager = EmbeddingManager()
    retriever = HybridRetriever(index, metadata, device=DEVICE)
    print("✓ Models loaded")

@app.post("/query", response_model=QueryResponse)
async def query_endpoint(request: QueryRequest):
    """Query the RAG system."""
    
    try:
        start = time.time()
        
        answer = query_index(
            request.question,
            k=request.k,
            filter_log_level=request.log_level,
            retriever=retriever,
            embedding_manager=embedding_manager
        )
        
        duration = time.time() - start
        
        return QueryResponse(
            question=request.question,
            answer=answer,
            processing_time=duration,
            success=True
        )
    
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/stats")
async def get_stats():
    """Get performance statistics."""
    return perf_monitor.metrics

@app.get("/health")
async def health():
    """Health check."""
    return {"status": "healthy", "device": DEVICE}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
```

**Usage:**
```bash
# Install: pip install fastapi uvicorn
python example7_api.py

# In another terminal:
curl -X POST "http://localhost:8000/query" \
  -H "Content-Type: application/json" \
  -d '{"question": "What is the main topic?", "k": 5}'
```

---

## Running Examples

1. **Ensure index exists:**
   ```bash
   python RAG_optimized_v8.py --index --folder ./documents
   ```

2. **Run any example:**
   ```bash
   python example1_basic.py
   python example2_interactive.py
   python example3_batch.py
   # etc.
   ```

3. **Check performance:**
   ```bash
   python RAG_optimized_v8.py --show-stats
   ```

---

## Tips for Examples

- **Modify paths:** Update `"./documents"` to your actual document folder
- **Adjust k:** Change `k=5` for more/fewer results
- **Switch models:** Edit config in `RAG_optimized_v8.py` before running
- **Error handling:** Add try-except for production use
- **Logging:** Use Python logging module for debugging
- **Monitoring:** Use `perf_monitor` to track performance

---

**Happy querying! 🚀**
