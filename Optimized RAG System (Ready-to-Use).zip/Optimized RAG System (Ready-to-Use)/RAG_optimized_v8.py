#!/usr/bin/env python3

"""
🚀 OPTIMIZED RAG System - Version 8 (Performance Enhanced)

Features:
✅ Direct Sentence-Transformers embeddings (10-50x faster than Ollama)
✅ BM25S for lexical search (500x faster than BM25Okapi)
✅ TinyBERT-L2-v2 cross-encoder (9x faster re-ranking)
✅ PyMuPDF for PDF parsing (15-66x faster than pypdf)
✅ IndexFlatL2 for small datasets (no IVF overhead)
✅ GPU acceleration support
✅ Hybrid FAISS + BM25S retrieval
✅ Conversational memory for multi-turn dialogue
✅ Performance monitoring and statistics
✅ Windows-compatible (tested on Windows + CPU/GPU)

Expected Performance:
• Indexing: 24 min → 1-2 minutes (12-24x speedup)
• Query: 60+ sec → 3-8 seconds (8-20x speedup)

Dependencies:
pip install sentence-transformers torch faiss-cpu numpy pymupdf bm25s Stemmer psutil tiktoken transformers ollama
Optional GPU: pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cu118
"""

import glob
import json
import os
import re
import time
from datetime import datetime
from typing import List, Tuple, Dict, Optional

import faiss
import numpy as np
import psutil
import tiktoken
import torch
import bm25s
from Stemmer import Stemmer

from sentence_transformers import SentenceTransformer
from transformers import AutoModelForSequenceClassification, AutoTokenizer
from ollama import chat, pull
import fitz  # PyMuPDF

# ============================================================================
# CONFIGURATION
# ============================================================================

# Embedding & LLM Models
EMBED_MODEL_NAME = "mixedbread-ai/mxbai-embed-large-v1"  # Sentence-Transformers model
TEXT_MODEL = "gemma3"  # Ollama model for generation
RERANKER_MODEL_NAME = "cross-encoder/ms-marco-TinyBERT-L2-v2"  # Faster re-ranker (9x speedup)

# Chunking
CHUNK_SIZE = 1000  # Increased from 500 for better context
CHUNK_OVERLAP = 250  # Increased from 200
LOG_LINES_PER_CHUNK = 50

# Batch Processing
BATCH_SIZE = 64  # Increased from 16 for better vectorization
EMBEDDING_BATCH_SIZE = 64

# Paths
INDEX_PATH = "index/faiss_index.bin"
METADATA_PATH = "metadata.json"
PERFORMANCE_LOG = "performance_metrics.json"

# Limits
MAX_FILE_SIZE_MB = 500
TOP_K_DEFAULT = 5  # Reduced from 8 for faster re-ranking
MAX_TOKENS = 8000

# Generation
TEMPERATURE = 0.3
TOP_P = 0.9
TOP_K = 40

# Flags
USE_GPU = torch.cuda.is_available()
DEVICE = 'cuda' if USE_GPU else 'cpu'

# Tokenizer cache
_tokenizer_cache = {}

print(f"\n{'='*70}")
print(f"🚀 RAG System v8 - Optimized Configuration")
print(f"{'='*70}")
print(f"Device: {DEVICE.upper()}")
print(f"GPU Available: {USE_GPU}")
print(f"Embedding Model: {EMBED_MODEL_NAME.split('/')[-1]}")
print(f"Cross-Encoder: {RERANKER_MODEL_NAME.split('/')[-1]}")
print(f"Chunk Size: {CHUNK_SIZE} | Batch Size: {BATCH_SIZE}")
print(f"{'='*70}\n")


# ============================================================================
# UTILITY FUNCTIONS
# ============================================================================

def count_tokens(text: str, model_name='gemma3') -> int:
    """Count tokens using tiktoken."""
    try:
        if model_name in _tokenizer_cache:
            tokenizer = _tokenizer_cache[model_name]
        else:
            tokenizer = tiktoken.encoding_for_model(model_name)
            _tokenizer_cache[model_name] = tokenizer
    except KeyError:
        tokenizer = tiktoken.get_encoding('cl100k_base')
    
    return len(tokenizer.encode(text))


def build_prompt_within_token_limit(context_chunks: List[str], question: str, max_tokens: int = MAX_TOKENS) -> str:
    """Build prompt while respecting token limits."""
    separator = "\n\n---\n\n"
    prompt_intro = "You are given the following extracted document chunks as context:\n\n"
    prompt_question = f"\n\nQuestion: {question}"
    
    allowed_tokens = max_tokens - count_tokens(prompt_intro) - count_tokens(prompt_question) - 100
    
    selected_chunks = []
    token_count = 0
    
    for chunk in context_chunks:
        chunk_tokens = count_tokens(chunk)
        if token_count + chunk_tokens > allowed_tokens:
            break
        selected_chunks.append(chunk)
        token_count += chunk_tokens
    
    context = separator.join(selected_chunks)
    prompt = f"{prompt_intro}{context}{prompt_question}"
    
    return prompt


# ============================================================================
# PERFORMANCE MONITORING
# ============================================================================

class PerformanceMonitor:
    """Track indexing and query performance metrics."""
    
    def __init__(self):
        self.metrics = {
            "indexing": {
                "start_time": None,
                "end_time": None,
                "duration_seconds": 0,
                "files_processed": 0,
                "chunks_created": 0,
                "embeddings_generated": 0,
                "bytes_processed": 0,
                "index_size_bytes": 0,
                "avg_cpu_percent": 0,
                "peak_memory_mb": 0,
                "chunks_per_second": 0
            },
            "queries": [],
            "evaluation": {
                "retrieval": [],
                "generation": []
            }
        }
        self.cpu_samples = []
        self.memory_samples = []
        self.process = psutil.Process()
    
    def start_indexing(self):
        self.metrics["indexing"]["start_time"] = datetime.now().isoformat()
        print(f"\n{'='*70}")
        print(f"📊 Performance Monitoring Started")
        print(f"{'='*70}\n")
    
    def sample_resources(self):
        """Sample CPU and memory usage."""
        try:
            cpu = psutil.cpu_percent(interval=0.1)
            memory = self.process.memory_info().rss / (1024 * 1024)
            self.cpu_samples.append(cpu)
            self.memory_samples.append(memory)
        except Exception:
            pass
    
    def record_file_processed(self, filepath: str, chunks: int):
        self.metrics["indexing"]["files_processed"] += 1
        self.metrics["indexing"]["chunks_created"] += chunks
        try:
            file_size = os.path.getsize(filepath)
            self.metrics["indexing"]["bytes_processed"] += file_size
        except Exception:
            pass
    
    def end_indexing(self):
        self.metrics["indexing"]["end_time"] = datetime.now().isoformat()
        start = datetime.fromisoformat(self.metrics["indexing"]["start_time"])
        end = datetime.fromisoformat(self.metrics["indexing"]["end_time"])
        duration = (end - start).total_seconds()
        
        self.metrics["indexing"]["duration_seconds"] = round(duration, 2)
        
        if duration > 0:
            self.metrics["indexing"]["chunks_per_second"] = round(
                self.metrics["indexing"]["chunks_created"] / duration, 2)
        
        if self.cpu_samples:
            self.metrics["indexing"]["avg_cpu_percent"] = round(
                sum(self.cpu_samples) / len(self.cpu_samples), 1)
        
        if self.memory_samples:
            self.metrics["indexing"]["peak_memory_mb"] = round(max(self.memory_samples), 1)
        
        try:
            self.metrics["indexing"]["index_size_bytes"] = os.path.getsize(INDEX_PATH)
        except Exception:
            pass
    
    def record_query(self, question: str, duration: float, chunks_retrieved: int, success: bool):
        self.metrics["queries"].append({
            "timestamp": datetime.now().isoformat(),
            "question": question[:100],
            "duration_seconds": round(duration, 3),
            "chunks_retrieved": chunks_retrieved,
            "success": success
        })
    
    def print_indexing_report(self):
        m = self.metrics["indexing"]
        print(f"\n{'='*70}")
        print(f"📊 INDEXING PERFORMANCE REPORT")
        print(f"{'='*70}\n")
        
        print(f"⏱️ Processing Time")
        print(f" Total Duration: {m['duration_seconds']} seconds ({m['duration_seconds']/60:.1f} minutes)")
        print(f" Start: {m['start_time']}")
        print(f" End: {m['end_time']}\n")
        
        print(f"📦 Data Processed")
        print(f" Files Processed: {m['files_processed']}")
        print(f" Chunks Created: {m['chunks_created']:,}")
        print(f" Embeddings Generated: {m['embeddings_generated']:,}")
        print(f" Data Volume: {m['bytes_processed'] / (1024*1024):.2f} MB\n")
        
        print(f"⚡ Performance")
        print(f" Throughput: {m['chunks_per_second']:.2f} chunks/second")
        print(f" Average CPU Usage: {m['avg_cpu_percent']}%")
        print(f" Peak Memory Usage: {m['peak_memory_mb']:.1f} MB\n")
        
        print(f"💾 Storage")
        print(f" Index Size: {m['index_size_bytes'] / (1024*1024):.2f} MB")
        if m['bytes_processed'] > 0:
            compression_ratio = m['index_size_bytes'] / m['bytes_processed']
            print(f" Compression Ratio: {compression_ratio:.2%} of original")
        
        print(f"\n{'='*70}\n")
    
    def print_query_stats(self):
        if not self.metrics["queries"]:
            print("No queries recorded yet.")
            return
        
        queries = self.metrics["queries"]
        durations = [q["duration_seconds"] for q in queries]
        
        print(f"\n{'='*70}")
        print(f"🔍 QUERY PERFORMANCE STATISTICS")
        print(f"{'='*70}\n")
        
        print(f"Total Queries: {len(queries)}")
        print(f"Average Response Time: {sum(durations)/len(durations):.3f} seconds")
        print(f"Fastest Query: {min(durations):.3f} seconds")
        print(f"Slowest Query: {max(durations):.3f} seconds")
        print(f"Success Rate: {sum(1 for q in queries if q['success'])/len(queries)*100:.1f}%")
        
        print(f"\n{'='*70}\n")
    
    def save_to_file(self, filepath: str = PERFORMANCE_LOG):
        os.makedirs(os.path.dirname(filepath) or '.', exist_ok=True)
        with open(filepath, 'w') as f:
            json.dump(self.metrics, f, indent=2)
        print(f"💾 Performance metrics saved to: {filepath}")


perf_monitor = PerformanceMonitor()


# ============================================================================
# TEXT EXTRACTION
# ============================================================================

def parse_log_line(line: str) -> Optional[Dict]:
    """Parse a single log line."""
    line = line.strip()
    
    if not line:
        return None
    
    if line.startswith('{'):
        try:
            return json.loads(line)
        except:
            pass
    
    patterns = [
        r'(\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}(?:\.\d+)?)\s+(\w+)\s+\[(.*?)\]\s+(.*)',
        r'([\d\.]+)\s+-\s+-\s+\[(.*?)\]\s+"(.*?)"\s+(\d+)',
        r'(\w+\s+\d+\s+\d{2}:\d{2}:\d{2})\s+(\S+)\s+(\S+):\s+(.*)',
        r'(\w+):\s+(.*)',
    ]
    
    for pattern in patterns:
        match = re.match(pattern, line)
        if match:
            return {"raw": line, "parsed": True, "groups": match.groups()}
    
    return {"raw": line, "parsed": False}


def chunk_log_file(filepath: str, lines_per_chunk: int = LOG_LINES_PER_CHUNK) -> List[Dict]:
    """Chunk a log file with metadata."""
    chunks = []
    current_chunk_lines = []
    current_chunk_metadata = {"start_line": 0, "log_levels": set()}
    
    line_number = 0
    
    try:
        with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
            for line in f:
                if line_number % 100 == 0:
                    perf_monitor.sample_resources()
                
                line_number += 1
                parsed = parse_log_line(line)
                
                if parsed:
                    current_chunk_lines.append(parsed.get("raw", line))
                    if parsed.get("parsed") and "groups" in parsed:
                        groups = parsed["groups"]
                        for group in groups:
                            if any(level in str(group).upper() for level in
                                   ["ERROR", "WARN", "INFO", "DEBUG", "FATAL"]):
                                current_chunk_metadata["log_levels"].add(str(group).upper())
                
                if len(current_chunk_lines) >= lines_per_chunk:
                    chunk_text = "\n".join(current_chunk_lines)
                    chunks.append({
                        "text": chunk_text,
                        "start_line": current_chunk_metadata["start_line"],
                        "end_line": line_number,
                        "log_levels": list(current_chunk_metadata["log_levels"]),
                        "line_count": len(current_chunk_lines)
                    })
                    current_chunk_lines = []
                    current_chunk_metadata = {"start_line": line_number + 1, "log_levels": set()}
        
        if current_chunk_lines:
            chunk_text = "\n".join(current_chunk_lines)
            chunks.append({
                "text": chunk_text,
                "start_line": current_chunk_metadata["start_line"],
                "end_line": line_number,
                "log_levels": list(current_chunk_metadata["log_levels"]),
                "line_count": len(current_chunk_lines)
            })
    
    except Exception as e:
        print(f"Error reading log file {filepath}: {e}")
        return []
    
    return chunks


def extract_text_from_file(path: str) -> str:
    """Extract text from various file formats."""
    ext = os.path.splitext(path)[1].lower()
    file_size_mb = os.path.getsize(path) / (1024 * 1024)
    
    if ext in [".log"]:
        return None
    
    # Text files
    if ext in [".txt", ".md", ".py", ".json", ".csv"]:
        try:
            with open(path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read()
        except Exception as e:
            print(f"Warning: Could not read {path}: {e}")
            return ""
    
    # PDF files - Using PyMuPDF (15-66x faster than pypdf)
    if ext == ".pdf":
        try:
            doc = fitz.open(path)
            text = ""
            for page in doc:
                text += page.get_text()
            doc.close()
            return text
        except Exception as e:
            print(f"Warning: Could not parse PDF {path}: {e}")
            return ""
    
    return ""


def chunk_text(text: str, chunk_size: int = CHUNK_SIZE, overlap: int = CHUNK_OVERLAP) -> List[str]:
    """Split text into overlapping chunks."""
    if not text or len(text.strip()) == 0:
        return []
    
    chunks = []
    start = 0
    length = len(text)
    
    while start < length:
        end = start + chunk_size
        chunk = text[start:end].strip()
        
        if chunk:
            chunks.append(chunk)
        
        if end >= length:
            break
        
        start = end - overlap
    
    return chunks


# ============================================================================
# EMBEDDING & INDEXING (OPTIMIZED)
# ============================================================================

class EmbeddingManager:
    """Manages embeddings using Sentence-Transformers (10-50x faster than Ollama)."""
    
    def __init__(self, model_name: str = EMBED_MODEL_NAME, device: str = DEVICE):
        self.model_name = model_name
        self.device = device
        print(f"Loading embedding model: {model_name}")
        self.model = SentenceTransformer(model_name)
        self.model.to(device)
        print(f"✓ Embedding model loaded on {device.upper()}\n")
    
    def embed_texts(self, texts: List[str], batch_size: int = EMBEDDING_BATCH_SIZE) -> np.ndarray:
        """Batch embed texts (optimized for speed)."""
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=True,
            convert_to_numpy=True,
            device=self.device
        )
        return embeddings


# ============================================================================
# HYBRID RETRIEVER (BM25S + FAISS + Cross-Encoder)
# ============================================================================

class HybridRetriever:
    """Hybrid retrieval using FAISS (semantic) + BM25S (lexical) + TinyBERT re-ranking."""
    
    def __init__(self, faiss_index, metadata, device=DEVICE, alpha=0.5):
        self.faiss_index = faiss_index
        self.metadata = metadata
        self.alpha = alpha
        self.device = device
        
        # BM25S initialization (500x faster than BM25Okapi)
        print("Initializing BM25S lexical search...")
        stemmer = Stemmer("english")
        corpus_texts = [doc['text'] for doc in metadata]
        corpus_tokens = bm25s.tokenize(corpus_texts, stemmer=stemmer)
        
        self.bm25 = bm25s.BM25()
        self.bm25.index(corpus_tokens)
        self.stemmer = stemmer
        print("✓ BM25S initialized\n")
        
        # Load cross-encoder re-ranker (TinyBERT-L2-v2 - 9x faster)
        print(f"Loading cross-encoder: {RERANKER_MODEL_NAME}")
        self.reranker_tokenizer = AutoTokenizer.from_pretrained(RERANKER_MODEL_NAME)
        self.reranker_model = AutoModelForSequenceClassification.from_pretrained(
            RERANKER_MODEL_NAME
        ).to(device)
        print(f"✓ Cross-encoder loaded on {device.upper()}\n")
    
    def query(self, question: str, embedding_fn, top_k: int = TOP_K_DEFAULT) -> List[str]:
        """Retrieve documents using hybrid search + re-ranking."""
        
        # BM25S lexical search
        query_tokens = bm25s.tokenize([question], stemmer=self.stemmer)
        bm25_results, bm25_scores = self.bm25.retrieve(query_tokens, k=top_k*2)
        
        # FAISS semantic search
        q_embedding = embedding_fn([question])[0].reshape(1, -1)
        distances, indices = self.faiss_index.search(q_embedding, top_k*2)
        
        # Combine candidates from both searches
        candidate_set = set()
        candidate_docs = {}
        
        for idx in indices[0]:
            if idx < len(self.metadata):
                candidate_set.add(idx)
                candidate_docs[idx] = self.metadata[idx]["text"]
        
        for result_row in bm25_results[0]:
            for idx, doc_text in enumerate(self.metadata):
                if doc_text["text"] in result_row and idx < len(self.metadata):
                    candidate_set.add(idx)
                    candidate_docs[idx] = self.metadata[idx]["text"]
        
        candidates = [candidate_docs[idx] for idx in list(candidate_set)[:top_k*2]]
        
        if not candidates:
            return []
        
        # Re-rank with TinyBERT-L2-v2 (9x faster than MiniLM-L12)
        return self._rerank_with_cross_encoder(question, candidates, top_k)
    
    def _rerank_with_cross_encoder(self, query: str, candidates: List[str], top_k: int) -> List[str]:
        """Re-rank candidates using cross-encoder."""
        if not candidates:
            return []
        
        inputs = self.reranker_tokenizer(
            [query] * len(candidates),
            candidates,
            padding=True,
            truncation=True,
            return_tensors='pt'
        ).to(self.device)
        
        with torch.no_grad():
            outputs = self.reranker_model(**inputs)
            scores = outputs.logits.squeeze(-1).cpu().numpy()
        
        ranked = sorted(zip(candidates, scores), key=lambda x: x[1], reverse=True)
        return [doc for doc, score in ranked[:top_k]]


# ============================================================================
# INDEXING PIPELINE
# ============================================================================

def create_optimized_faiss_index(embeddings: np.ndarray) -> faiss.Index:
    """Create FAISS index optimized for dataset size."""
    d = embeddings.shape[1]
    n_vectors = embeddings.shape[0]
    
    print(f"\nCreating FAISS index for {n_vectors} vectors ({d} dimensions)...")
    
    if n_vectors < 10000:
        # Use flat index for small datasets (no IVF overhead)
        index = faiss.IndexFlatL2(d)
        index.add(embeddings)
        print(f"✓ FAISS FlatL2 index created (exact search, optimal for small datasets)")
    else:
        # Use IVF for large datasets
        quantizer = faiss.IndexFlatL2(d)
        nlist = min(int(4 * np.sqrt(n_vectors)), 256)
        index = faiss.IndexIVFFlat(quantizer, d, nlist, faiss.METRIC_L2)
        index.train(embeddings)
        index.add(embeddings)
        index.nprobe = min(20, nlist)
        print(f"✓ FAISS IVFFlat index created with {nlist} clusters")
    
    return index


def index_folder(
    folder_path: str,
    index_path: str = INDEX_PATH,
    metadata_path: str = METADATA_PATH,
    text_extensions: Optional[List[str]] = None
) -> None:
    """Index all documents in a folder."""
    
    perf_monitor.start_indexing()
    
    if text_extensions is None:
        text_extensions = ["*.txt", "*.md", "*.py", "*.json", "*.csv", "*.pdf", "*.log"]
    
    # Find all files
    files = []
    for pattern in text_extensions:
        files.extend(glob.glob(os.path.join(folder_path, "**", pattern), recursive=True))
    
    print(f"Found {len(files)} files to process.\n")
    
    if not files:
        raise RuntimeError(f"No files found in {folder_path}")
    
    # Initialize embedding manager
    embedding_manager = EmbeddingManager()
    
    metadata = []
    all_chunks = []
    
    # Extract chunks from all files
    for file_idx, path in enumerate(files, 1):
        ext = os.path.splitext(path)[1].lower()
        file_size_mb = os.path.getsize(path) / (1024 * 1024)
        
        print(f"Processing [{file_idx}/{len(files)}]: {os.path.basename(path)} ({file_size_mb:.2f} MB)")
        perf_monitor.sample_resources()
        
        if ext == ".log":
            log_chunks = chunk_log_file(path, LOG_LINES_PER_CHUNK)
            if not log_chunks:
                print(" No valid log entries found")
                continue
            
            print(f" Created {len(log_chunks)} log chunks")
            perf_monitor.record_file_processed(path, len(log_chunks))
            
            for chunk in log_chunks:
                all_chunks.append(chunk["text"])
                metadata.append({
                    "path": path,
                    "text": chunk["text"][:1000],
                    "file_type": "log",
                    "start_line": chunk["start_line"],
                    "end_line": chunk["end_line"],
                    "log_levels": chunk["log_levels"],
                    "line_count": chunk["line_count"]
                })
        else:
            text = extract_text_from_file(path)
            if not text:
                print(" Skipping (no text extracted)")
                continue
            
            chunks = chunk_text(text)
            print(f" Created {len(chunks)} chunks")
            perf_monitor.record_file_processed(path, len(chunks))
            
            for chunk in chunks:
                all_chunks.append(chunk)
                metadata.append({
                    "path": path,
                    "text": chunk[:1000],
                    "file_type": ext[1:] if ext else "unknown"
                })
    
    if not all_chunks:
        raise RuntimeError("No chunks created from documents")
    
    print(f"\n✓ Extracted {len(all_chunks)} total chunks")
    
    # Generate embeddings in batches
    print(f"\nGenerating embeddings (batch size: {EMBEDDING_BATCH_SIZE})...")
    embeddings = embedding_manager.embed_texts(all_chunks, batch_size=EMBEDDING_BATCH_SIZE)
    
    perf_monitor.metrics["indexing"]["embeddings_generated"] = len(embeddings)
    
    # Create FAISS index
    index = create_optimized_faiss_index(embeddings)
    
    # Save index and metadata
    os.makedirs(os.path.dirname(index_path) or '.', exist_ok=True)
    faiss.write_index(index, index_path)
    
    with open(metadata_path, "w", encoding="utf-8") as f:
        json.dump(metadata, f, ensure_ascii=False, indent=2)
    
    perf_monitor.end_indexing()
    perf_monitor.print_indexing_report()
    perf_monitor.save_to_file()
    
    print(f"✅ Indexing complete!")
    print(f"   Index saved: {index_path}")
    print(f"   Metadata saved: {metadata_path}\n")


# ============================================================================
# QUERYING
# ============================================================================

def load_index(
    index_path: str = INDEX_PATH,
    metadata_path: str = METADATA_PATH
) -> Tuple[faiss.Index, List[Dict]]:
    """Load FAISS index and metadata."""
    
    if not os.path.exists(index_path):
        raise FileNotFoundError(f"Index not found at {index_path}. Run with --index first.")
    
    if not os.path.exists(metadata_path):
        raise FileNotFoundError(f"Metadata not found at {metadata_path}. Run with --index first.")
    
    index = faiss.read_index(index_path)
    
    with open(metadata_path, "r", encoding="utf-8") as f:
        metadata = json.load(f)
    
    return index, metadata


class ConversationalMemory:
    """Store conversation history for multi-turn dialogue."""
    
    def __init__(self, max_turns: int = 5):
        self.memory = []
        self.max_turns = max_turns
    
    def add_turn(self, user_input: str, system_response: str):
        self.memory.append((user_input, system_response))
        if len(self.memory) > self.max_turns:
            self.memory.pop(0)
    
    def get_context(self) -> str:
        return "\n".join([f"User: {u}\nSystem: {s}" for u, s in self.memory])


def query_index(
    question: str,
    k: int = TOP_K_DEFAULT,
    filter_log_level: Optional[str] = None,
    retriever: Optional[HybridRetriever] = None,
    embedding_manager: Optional[EmbeddingManager] = None,
    conversational_memory: Optional[ConversationalMemory] = None
) -> str:
    """Query the indexed documents and generate answer."""
    
    query_start = time.time()
    success = False
    
    try:
        if retriever is None or embedding_manager is None:
            print("Loading index and metadata...")
            index, metadata = load_index()
            embedding_manager = EmbeddingManager()
            retriever = HybridRetriever(index, metadata, device=DEVICE)
        
        # Prepend conversational context if available
        if conversational_memory:
            context = conversational_memory.get_context()
            full_query = f"{context}\n\n{question}"
        else:
            full_query = question
        
        print("Performing hybrid retrieval + re-ranking...")
        results = retriever.query(full_query, embedding_fn=embedding_manager.embed_texts, top_k=k)
        
        if not results:
            return "No relevant documents found."
        
        # Filter by log level if specified
        filtered_results = []
        for res_text in results:
            if filter_log_level and f"Log Levels: {filter_log_level}" not in res_text:
                continue
            filtered_results.append(res_text)
        
        if not filtered_results:
            return "No relevant documents found after filtering."
        
        # Build prompt and generate answer
        prompt = build_prompt_within_token_limit(filtered_results, full_query)
        
        print(f"Generating answer with {TEXT_MODEL} at temperature {TEMPERATURE}...")
        response = chat(
            model=TEXT_MODEL,
            messages=[{"role": "user", "content": prompt}],
            options={
                "temperature": TEMPERATURE,
                "top_p": TOP_P,
                "top_k": TOP_K
            }
        )
        
        success = True
        return response["message"]["content"]
    
    finally:
        duration = time.time() - query_start
        perf_monitor.record_query(question, duration, k, success)
        print(f"\n⏱️ Query completed in {duration:.3f} seconds\n")


# ============================================================================
# MAIN
# ============================================================================

def main():
    import argparse
    
    parser = argparse.ArgumentParser(
        description="🚀 Optimized RAG System (v8 - Performance Enhanced)",
        formatter_class=argparse.RawDescriptionHelpFormatter
    )
    
    parser.add_argument("--index", action="store_true", help="Create/rebuild index")
    parser.add_argument("--folder", type=str, default=".", help="Folder to index")
    parser.add_argument("--query", type=str, help="Query the indexed documents")
    parser.add_argument("--k", type=int, default=TOP_K_DEFAULT, help="Number of chunks to retrieve")
    parser.add_argument("--log-level", type=str,
                        choices=["ERROR", "WARN", "INFO", "DEBUG", "FATAL"],
                        help="Filter by log level")
    parser.add_argument("--show-stats", action="store_true",
                        help="Show performance statistics")
    
    args = parser.parse_args()
    
    if args.show_stats:
        try:
            with open(PERFORMANCE_LOG, 'r') as f:
                perf_monitor.metrics = json.load(f)
            perf_monitor.print_indexing_report()
            perf_monitor.print_query_stats()
        except FileNotFoundError:
            print("No performance data found. Run index or query first.")
        return
    
    if not args.index and not args.query:
        parser.print_help()
        return
    
    if args.index:
        print("Checking and pulling Ollama models...")
        for model_name in [TEXT_MODEL]:
            try:
                print(f" Pulling {model_name}...")
                pull(model_name)
                print(f" ✓ {model_name} ready")
            except Exception as e:
                print(f" Warning: Could not pull {model_name}: {e}")
        
        print(f"\nIndexing folder: {args.folder}")
        index_folder(args.folder)
    
    if args.query:
        print("Setting up retriever...\n")
        index, metadata = load_index()
        embedding_manager = EmbeddingManager()
        retriever = HybridRetriever(index, metadata, device=DEVICE)
        
        conv_memory = ConversationalMemory(max_turns=5)
        
        answer = query_index(
            args.query,
            k=args.k,
            filter_log_level=args.log_level,
            retriever=retriever,
            embedding_manager=embedding_manager,
            conversational_memory=conv_memory
        )
        
        print("\n" + "="*70)
        print("ANSWER")
        print("="*70 + "\n")
        print(answer + "\n")
        perf_monitor.print_query_stats()


if __name__ == "__main__":
    main()
